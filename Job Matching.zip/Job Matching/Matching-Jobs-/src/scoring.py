def calculate_numeric_score(job_val, candidate_val):
    # Logic for numerical score (e.g., salary range overlap)
    pass

def calculate_location_score(job_location, candidate_location):
    return 1 if job_location == candidate_location else 0.5