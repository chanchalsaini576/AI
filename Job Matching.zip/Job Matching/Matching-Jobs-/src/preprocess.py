def preprocess_text(text):
    return " ".join(text.lower().split()) 